
version = "2.0.0"
name = "CloneChat Bot"
description = "Bot do Telegram para clonagem de chats usando Telethon"
