from protect_content import clonechat_protect_up

def main():
    clonechat_protect_up.main()

if __name__ == '__main__':
    main()