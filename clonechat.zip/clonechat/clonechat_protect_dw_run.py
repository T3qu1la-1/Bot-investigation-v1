from protect_content import clonechat_protect_down


def main():
    clonechat_protect_down.main()


if __name__ == "__main__":
    main()
