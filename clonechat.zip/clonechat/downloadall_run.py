from protect_content import downloadall

def main():
    downloadall.main()

if __name__ == '__main__':
    main()